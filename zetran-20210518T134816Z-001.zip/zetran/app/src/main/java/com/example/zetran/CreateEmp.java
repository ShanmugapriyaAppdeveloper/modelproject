package com.example.zetran;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CreateEmp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_emp);
        EditText empname,empId,empdept;
        Button bt_save;

            empname = findViewById(R.id.et_emp_name);

            empId = findViewById(R.id.et_emp_id);
            empdept = findViewById(R.id.et_emp_dept);
            bt_save = findViewById(R.id.bt_save);
            bt_save.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    Toast.makeText(getApplicationContext(), "saved…..",Toast.LENGTH_SHORT).show();
                }
            });
        }

    }
